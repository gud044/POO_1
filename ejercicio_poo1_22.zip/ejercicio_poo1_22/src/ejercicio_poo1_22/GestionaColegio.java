package ejercicio_poo1_22;

import java.util.ArrayList;
import java.util.Scanner;

public class GestionaColegio {

	public static Alumnos registrarAlumnos() {
		Alumnos alumno = new Alumnos().alta();
		return alumno;
	}

	public static Profesores registrarProfesores() {
		Profesores profesor = new Profesores().alta();
		return profesor;
		
	}

	public static void mostrarAlumnos(ArrayList<Alumnos> AlumnoArray) {
		for(int i=0; i<AlumnoArray.size();i++) {
			Alumnos alumno = AlumnoArray.get(i);
			alumno.mostrarPersona();
			
		}
	}
	
	public static void mostrarProfesores(ArrayList<Profesores> ProfesorArray) {
		for(int i=0; i<ProfesorArray.size();i++) {
			Profesores profesor = ProfesorArray.get(i);
			profesor.mostrarPersona();
		}
	}
	
	public static void totalPYS(ArrayList<Alumnos> AlumnoArray) {
		int total=0;
		for(int i=0; i<AlumnoArray.size();i++){
			if (AlumnoArray.get(i).getCurso().equals("primero") || AlumnoArray.get(i).getCurso().equals("segundo")) {
				total= total+1;
			}
		}
		System.out.println("Todos los alumnos matriculados en primero y segundo son: " + total);
	}
	
	public static void revisarAprobados(ArrayList<Alumnos> AlumnoArray) {
		int total=0;
		for(int i=0; i<AlumnoArray.size();i++){
			if (AlumnoArray.get(i).getNota()>=5) {
				total= total+1;
			}
		}
		System.out.println("Todos los alumnos aprobados son: " + total);
	}
	
	public static void profesorConMas(ArrayList<Profesores> ProfesorArray) {
		int asignaturas = 0;
		String dni="a";
		for(int i=0; i<ProfesorArray.size();i++) {
			if(ProfesorArray.get(i).isEsTutor()==true && ProfesorArray.get(i).getCantidadAsignaturas()>asignaturas) {
				asignaturas=ProfesorArray.get(i).getCantidadAsignaturas();
				dni=ProfesorArray.get(i).getDni();
			}
		}
		
		for (int i=0; i<ProfesorArray.size();i++) {
			if (dni==ProfesorArray.get(i).getDni()) {
				System.out.println("El tutor con mas asignaturas es:");
				System.out.println(ProfesorArray.get(i).getNombre());
				System.out.print(ProfesorArray.get(i).getApellido());
				System.out.println(" ");
			}
		}
	}
	
	public static void main(String[] args) {
		int elec=1;
		Scanner entrada = new Scanner (System.in);
		ArrayList<Alumnos> AlumnoArray = new ArrayList<Alumnos>();
		ArrayList<Profesores> ProfesorArray = new ArrayList<Profesores>();
		do {
			elec=inicio(entrada);
			if(elec==1){
				AlumnoArray.add(registrarAlumnos());
			}else if(elec==2) {
				ProfesorArray.add(registrarProfesores());
			}else if(elec==3) {
				mostrarAlumnos(AlumnoArray);
			}else if(elec==4) {
				mostrarProfesores(ProfesorArray);
			}else if(elec==5) {
				totalPYS(AlumnoArray);
			}else if(elec==6) {
				revisarAprobados(AlumnoArray);
			}else if(elec==7) {
				profesorConMas(ProfesorArray);
			}
		}while(elec!=0);
	}

	public static int inicio(Scanner entrada) {
		int eleccion;
		System.out.println("Seleccione que quiere hacer:");
		System.out.println("1. A�adir un nuevo alumno.");
		System.out.println("2. A�adir un nuevo profesor.");
		System.out.println("3. Mostrar todos los alumnos.");
		System.out.println("4. Mostrar todos los profesores.");
		System.out.println("5. Para ver la cantidad de alumnos matriculados en primero y en segundo.");
		System.out.println("6. Para ver cuantos alumnos han aprovado.");
		System.out.println("7. Para ver cual es el tutor con mas asignaturas.");
		System.out.println("0. Salir de la aplicacion.");
		eleccion=entrada.nextInt();
		return eleccion;
	}

}
