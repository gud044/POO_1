package ejercicio_poo1_22;

import java.util.Scanner;

public class Profesores extends Persona{
	Scanner entrada = new Scanner (System.in);
	private boolean esTutor;
	private int cantidadAsignaturas;
	
	public Profesores() {
		
	}
	
	public Profesores(String nombre, String apellido, String telefono, String dni, boolean esTutor, int cantidad) {
		this.esTutor=esTutor;
		this.cantidadAsignaturas=cantidad;
	}
	
	public boolean isEsTutor() {
		return esTutor;
	}
	public int getCantidadAsignaturas() {
		return cantidadAsignaturas;
	}

	public void setEsTutor(boolean esTutor) {
		this.esTutor = esTutor;
	}
	public void setCantidadAsignaturas(int cantidadAsignaturas) {
		this.cantidadAsignaturas = cantidadAsignaturas;
	}
	
	public void mostrarPersona() {
		System.out.println("Profesor:" + getNombre());
		System.out.println("Profesor:" + getApellido());
		System.out.println("Profesor:" + getTelefono());
		System.out.println("Profesor:" + getDni());
		System.out.println("Profesor:" + isEsTutor());
		System.out.println("Profesor:" + getCantidadAsignaturas());
		System.out.println(" ");
	}

	public Profesores alta() {
		
		entrada.nextLine();
		System.out.println("Introduzca el nombre.");
		String nombre = entrada.next();
		entrada.nextLine();
		System.out.println("Introduzca el apellido.");
		String apellido = entrada.next();
		entrada.nextLine();
		System.out.println("Introduzca el telefono.");
		String telefono = entrada.next();
		entrada.nextLine();
		System.out.println("Introduzca el dni.");
		String dni = entrada.next();
		entrada.nextLine();
		System.out.println("Diga con true o false si es tutor.");
		boolean esTutor=entrada.nextBoolean();
		entrada.nextLine();
		System.out.println("Introduzca la cantidad de asignaturas.");
		int cantidad = entrada.nextInt();
		entrada.nextLine();
		Profesores profesor = new Profesores(nombre, apellido, telefono, dni, esTutor, cantidad);
		return profesor;
	}
	
	
}
