package ejercicio_poo1_22;

import java.util.Scanner;

public class Alumnos extends Persona{
	Scanner entrada = new Scanner (System.in);
	private String curso;
	private int nota;
	
	public Alumnos() {
		
	}

	public Alumnos(String nombre, String apellido, String telefono, String dni, String curso, int nota) {
		this.curso=curso;
		this.nota=nota;
	}

	public String getCurso() {
		return curso;
	}

	public int getNota() {
		return nota;
	}

	public void setCurso(String curso) {
		this.curso = curso;
	}

	public void setNota(int nota) {
		this.nota = nota;
	}
	
	public void mostrarPersona() {
		System.out.println("Alumno:" + getNombre());
		System.out.println("Alumno:" + getApellido());
		System.out.println("Alumno:" + getTelefono());
		System.out.println("Alumno:" + getDni());
		System.out.println("Alumno:" + getCurso());
		System.out.println("Alumno:" + getNota());
		System.out.println(" ");
	}
	
	public Alumnos alta() {
		entrada.nextLine();
		System.out.println("Introduzca el nombre.");
		String nombre = entrada.next();
		entrada.nextLine();
		System.out.println("Introduzca el apellido.");
		String apellido = entrada.next();
		entrada.nextLine();
		System.out.println("Introduzca el telefono.");
		String telefono = entrada.next();
		entrada.nextLine();
		System.out.println("Introduzca el dni.");
		String dni = entrada.next();
		entrada.nextLine();
		System.out.println("Introduzca el curso (en minusculas).");
		String curso = entrada.next();
		entrada.nextLine();
		System.out.println("Introduzca la nota.");
		int nota = entrada.nextInt();
		entrada.nextLine();
		Alumnos alumno = new Alumnos(nombre, apellido, telefono, dni, curso, nota);
		return alumno;
	}
}
